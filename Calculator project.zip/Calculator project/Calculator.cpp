#include <iostream>
using namespace std;
int main()
{
	float j,k;

	cout<<"enter the value of j and k "<<endl;
	cin>>j>>k;
	cout<<j<<"*"<<k<<"="<<j*k<<endl;
	cout<<j<<"/"<<k<<"="<<j/k<<endl;
	cout<<j<<"+"<<k<<"="<<j+k<<endl;
	cout<<j<<"-"<<k<<"="<<j-k<<endl;
	
	return 0;
}

